import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class FormularioCadastro {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Cadastros");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        //Labels
        JLabel labelNome = new JLabel("Nome:");
        JLabel labelSobrenome = new JLabel ("Sobrenome:");
        JLabel labelEMail = new JLabel ("Email:");

        //campos de texto
        JTextField campoNome = new JTextField(10);
        JTextField campoSobrenome = new JTextField(10);
        JTextField campoEMail = new JTextField(10);

        //botao completar cadastro
        JButton botaoCadastro = new JButton("Completar cadastro");
        
        // Ação do botão (gerar uma nova janela)
        botaoCadastro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame novaJanela = new JFrame("Cadastro concluído");
                novaJanela.setSize(1000, 1800);
                novaJanela.setLayout(new FlowLayout());
                String nomeCompleto = campoNome.getText() + " " + campoSobrenome.getText();
                novaJanela.add(new JLabel("Cadastro realizado com sucesso, bem vindo " + nomeCompleto + "!" ));
                novaJanela.add(new JLabel("")); // espaço branco como espaço
                novaJanela.add(new JLabel("Muito obrigado por se cadastrar senhor(a), agora você pode clicar no botão feliz!"));
                novaJanela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
                //yay butãom!!!!!!!
                JButton happiestButton = new JButton("☺");
                happiestButton.setSize(450, 300);

                //Ação botão feliz
                happiestButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e){
                        JOptionPane.showMessageDialog(novaJanela, "yay! você apertou o botão, ele esta feliz agora!");
                    }
                });

                novaJanela.add(happiestButton);

                novaJanela.setLocationRelativeTo(frame); // abre no centro da janela principal
                novaJanela.setVisible(true); //exibir janela
            }
        });

        //adiccionando os componentes
        frame.add(labelNome);
        frame.add(campoNome);
        frame.add(labelSobrenome);
        frame.add(campoSobrenome);
        frame.add(labelEMail);
        frame.add(campoEMail);
        frame.add(botaoCadastro);
        
        //quando a janale aperecer, sera no meio
        frame.setLocationRelativeTo(null);
        //exibir janela
        frame.setVisible(true);
}}